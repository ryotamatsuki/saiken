# Stage 2: R7・R8 都道府県公金・基金運用 公開情報調査

調査基準日: 2026-09-15

## 目的

第1段階のR4～R6全国統一データに、R7（FY2025）・R8（FY2026）の各都道府県公式公表資料を接続し、
愛媛県の国債運用開始後の現在地を他県と比較するための基礎データを作る。

政策上の問いは、
「愛媛県は、金利正常化局面において、安全性・流動性を確保しながら、他県に比べて運用収益機会を取り逃していないか」
である。

## 調査範囲

- 47都道府県すべて
- R7・R8の各年度について公式資料を検索
- R7は年間実績を優先
- R8は年度途中のため、実績・計画・方針を `period_type` で区分
- 公開資料に数値がない場合は推測せず `SEARCHED_NOT_FOUND` または `PARTIAL_OFFICIAL`
- 愛媛県のR7・R8は公開情報だけでは比較に必要な数値が不足するため `INTERNAL_DATA_REQUIRED`

## 重要な制約

R4～R6は総務省/e-Statの全国統一統計だが、R7・R8は各都道府県の個別公表資料である。
R7・R8の数値は定義・時点・対象範囲が必ずしも統一されていない。
特に「基金単独」と「歳計現金等を含む公金全体」を混同しない。

本データセットは公開情報を横断的に棚卸ししたベースであり、
公開数値が揃わない県を含めた全国一律ランキングを作ることを目的としない。

## 完了判定

**STAGE 2 COMPLETE（公開情報棚卸しとして）**

- R7: 47/47都道府県を検索済み
- R8: 47/47都道府県を検索済み
- Stage2行数: 94
- R4～R8統合データ: 235行（47×5年度）
- QA: 19/19項目PASS
- 愛媛県内部補完項目: 24項目

「COMPLETE」は、全県で同一項目の数値が公開されていることを意味しない。
非公表・検索未確認の項目を明示的に分類し、推測せず残したという意味である。

## 主なファイル

- `processed/prefecture_R7_R8_public_fund_investment_long.csv`
- `processed/prefecture_R7_R8_disclosure_matrix.csv`
- `processed/prefecture_R4_R8_integrated.csv`
- `processed/ehime_internal_data_required.csv`
- `processed/comparison_candidates.csv`
- `processed/advanced_management_prefectures.csv`
- `processed/QA.csv`
- `sources/source_dictionary.csv`
- `sources/search_log.csv`
- `reports/prefecture_R7_R8_public_fund_investment_analysis.md`
